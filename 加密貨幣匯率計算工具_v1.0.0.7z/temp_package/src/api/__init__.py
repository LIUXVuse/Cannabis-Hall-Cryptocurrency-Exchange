"""
API客戶端模組
包含與外部服務（如Binance和TT Exchange）的接口實現
"""
