"""
Marijuana Crypto Currency Exchange
加密貨幣匯率計算工具主包
"""

# 使src成為一個有效的Python包
